#!/usr/bin/python
#!/usr/bin/python3
#!/usr/bin/env python
#!/usr/bin/env python3
# -*- coding: utf8 -*-

# Python Web Based English To Bangla Translator.
# date                 :-   
# author               :- Md Jabed Ali(jabed)

import entobn as bn_trnslt
 
bn_trnslt.googel_translate()
